#!/bin/bash
sudo systemctl restart apache2
